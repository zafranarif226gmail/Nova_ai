# Lift Terminal — Android APK builder

This project builds a branded Lift Terminal APK from the upstream Termux Android app source.
It is intended for Android 11 / ARM64 devices such as vivo 1933.

## What it is
- A real Termux-based terminal app under the display name **Lift Terminal**.
- Uses Termux's Linux userspace/bootstrap and package system, so commands such as `pkg` and `git clone` can work after installation and package setup.
- No ads are added by this project.
- The app requires internet to download packages such as Git when they are not already installed.

## Important
This ZIP is a **builder**, not an APK. The APK must be built by GitHub Actions after you upload these files to a GitHub repository. This workflow fetches upstream Termux source and changes the displayed app name before building. It does not change the upstream package ID or imply that the app is officially supported by the Termux project.

## Build APK using GitHub (no Termux on your phone)
1. Create a new GitHub repository named `Lift-Terminal`.
2. Upload the contents of this ZIP to that repository (including the hidden `.github` folder).
3. Open **Actions** and enable workflows if GitHub asks.
4. Select **Build Lift Terminal APK** → **Run workflow**.
5. Wait for the run to finish, open the successful run, and download the `Lift-Terminal-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install the APK. If Android asks, allow installation from your browser/files app.

## Device notes
- Target device: Android 11, ARM64.
- Keep package downloads modest; installing many packages increases storage use.
- This build is a branded upstream-source build, not a separate implementation. Review upstream licenses and notices before redistribution.
